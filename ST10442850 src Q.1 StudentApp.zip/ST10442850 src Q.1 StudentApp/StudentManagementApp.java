import java.util.List;
import java.util.Scanner;
import java.util.ArrayList;

public class StudentManagementApp {

    private static List<Student> students = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        boolean quit = false;

        while (!quit) {
            System.out.println("Student Management App");
            System.out.println("*****************************");
            System.out.println("Enter (1) to launch menu or any other key to exit");

            String command = scanner.nextLine();

            if (command.equals("1")) {
                System.out.println("Please select one of the following menu items:");
                System.out.println("1. Capture a new student");
                System.out.println("2. Search for a student");
                System.out.println("3. Delete a student");
                System.out.println("4. Print a student report");
                System.out.println("5. Exit App");

                String menuChoice = scanner.nextLine();


                menuChoice = scanner.nextLine();

                switch (menuChoice) {
                    case "1":
                        captureNewStudent("10111", "J.Bloggs", 19, "jbloggs@gmail.com", "disd");
                        break;
                    case "2":
                        searchForStudent();
                        break;
                    case "3":
                        deleteStudent();
                        break;
                    case "4":
                        printStudentReport();
                        break;
                    case "5":
                        quit = true;
                        System.out.println("Exiting the application.");
                        break;
                    default:
                        System.out.println("Invalid option. Please try again.");
                }
            } else {
                quit = true;
                System.out.println("Exiting the application.");
            }
        }
        scanner.close();
    }

    private static void captureNewStudent(String number, String s, int i, String mail, String disd) {
        System.out.println("CAPTURE A NEW STUDENT");
        System.out.println("*******************************");

        System.out.print("Enter the student ID: ");
        String id = scanner.nextLine();

        System.out.print("Enter the student name: ");
        String name = scanner.nextLine();

        int age = 0;
        boolean validAge = false;
        while (!validAge) {
            System.out.print("Enter the student age: ");
            String ageInput = scanner.nextLine();
            try {
                age = Integer.parseInt(ageInput);
                if (age >= 16) {
                    validAge = true;
                } else {
                    System.out.println("You have entered an incorrect student age!!! Please re-enter the student age.");
                }
            } catch (NumberFormatException e) {
                System.out.println("You have entered an incorrect student age!!! Please re-enter the student age.");
            }
        }

        System.out.print("Enter the student email: ");
        String email = scanner.nextLine();

        System.out.print("Enter the student course: ");
        String course = scanner.nextLine();

        students.add(new Student(id, name, age, email, course));
        System.out.println("Student details have been successfully saved.");
    }

    private static void searchForStudent() {
        System.out.println("Enter the student ID to search: ");
        String id = scanner.nextLine();

        for (Student student : students) {
            if (student.getId().equals(id)) {
                System.out.println(student);
                return;
            }
        }
        System.out.println("Student with ID: " + id + " was not found!");
    }

    private static void deleteStudent() {
        System.out.println("Enter the student ID to delete: ");
        String id = scanner.nextLine();

        for (Student student : students) {
            if (student.getId().equals(id)) {
                System.out.println("Are you sure you want to delete student " + id + " from the system? Yes (y) to delete.");
                String confirmation = scanner.nextLine();
                if (confirmation.equalsIgnoreCase("y")) {
                    students.remove(student);
                    System.out.println("Student with ID: " + id + " was deleted!");
                }
                return;
            }
        }
        System.out.println("Student with ID: " + id + " was not found!");
    }

    private static void printStudentReport() {
        if (students.isEmpty()) {
            System.out.println("No students found.");
        } else {
            int i = 1;
            for (Student student : students) {
                System.out.println("STUDENT " + i + "\n" + student);
                i++;
            }
    }


    }
}