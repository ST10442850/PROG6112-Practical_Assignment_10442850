import java.util.Scanner;

public class Student {
    private String id;
    private String name;
    private int age;
    private String email;
    private String course;
    private Student stud;

    public Student(String id, String name, int age, String email, String course) {
        stud.id = id;
        stud.name = name;
        stud.age = age;
        stud.email = email;
        stud.course = course;

    }
    public String getId() {
        return id;
    }
    public void setId(String id) {
        stud.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        stud.name = name;
    }
    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        stud.age = age;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        stud.email = email;
    }
    public String getCourse() {
        return course;
    }
    public void setCourse(String course) {
        stud.course = course;
    }

    public String toString() {
        return "Student [id=" + id + ", name=" + name + ", age=" + age + ", email=" + email
                + ", course=" + course + "]";
    }
}
