import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;

public class StudentManagementApplicationTest {

    private StudentManagementApp app;

    @BeforeEach
    public void setUp() {
        app = new StudentManagementApp();
    }

    @Test
    public void testCaptureNewStudent() {
        app.captureNewStudent("10111", "J.Bloggs", 19, "jbloggs@gmail.com", "disd");
        List<Student> students = app.getStudents();
        assertEquals(1, students.size());

        Student stud = students.get(0);
        assertEquals("10111", stud.getId());
        assertEquals("J.Bloggs", stud.getName());
        assertEquals(19, stud.getAge());
        assertEquals("jbloggs@gmail.com", stud.getEmail());
        assertEquals("disd", stud.getCourse());
    }

    @Test
    public void testSearchStudent() {
        app.captureNewStudent("10111", "J.Bloggs", 19, "jbloggs@gmail.com", "disd");
        Student stud = app.searchStudent("10111");
        assertNotNull(stud);
        assertEquals("10111", stud.getId());
    }

    @Test
    public void testSearchStudentNotFound() {
        Student stud = app.searchStudent("99999");
        assertNull(stud);
    }

    @Test
    public void testDeleteStudent() {
        app.captureNewStudent("10111", "J.Bloggs", 19, "jbloggs@gmail.com", "disd");
        assertTrue(app.deleteStudent("10111"));
        assertNull(app.searchStudent("10111"));
    }

    @Test
    public void testDeleteStudentNotFound() {
        assertFalse(app.deleteStudent("99999"));
    }

    @Test
    public void testStudentReport() {
        app.captureNewStudent("10111", "J.Bloggs", 19, "jbloggs@gmail.com", "disd");
        String report = app.generateStudentReport();
        assertTrue(report.contains("J.Bloggs"));
        assertTrue(report.contains("10111"));
    }

    @Test
    public void testExitApplication() {
        // Assuming the exit method terminates the program or performs some other action,
        // it would be hard to unit test. You may want to test for behavior before and after
        // this method call.
    }
}
