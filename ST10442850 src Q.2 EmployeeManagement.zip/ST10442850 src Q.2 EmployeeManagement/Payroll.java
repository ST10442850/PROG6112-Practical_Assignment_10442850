public class Payroll {
    public static void generatePayrollReport(EmployeeDatabase database) {
        System.out.println("----- Payroll Report -----");
        database.displayAllEmployees();
        System.out.println("Total Payroll: " + database.calculateTotalPayroll());
    }
}


