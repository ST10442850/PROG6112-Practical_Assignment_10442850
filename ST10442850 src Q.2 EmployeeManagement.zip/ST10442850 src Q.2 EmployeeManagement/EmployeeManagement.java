import java.util.Scanner;

public class EmployeeManagement {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        EmployeeDatabase database = new EmployeeDatabase();

        while (true) {
            System.out.println("1. Add Employee");
            System.out.println("2. Update Employee");
            System.out.println("3. Display All Employees");
            System.out.println("4. Generate Payroll Report");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.println("Enter Employee Name:");
                    String name = scanner.nextLine();
                    System.out.println("Enter Employee ID:");
                    int id = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.println("Enter Department:");
                    String department = scanner.nextLine();
                    System.out.println("Enter Salary:");
                    double salary = scanner.nextDouble();
                    Employee employee = new Employee(name, id, department, salary);
                    database.addEmployee(employee);
                    break;

                case 2:
                    System.out.println("Enter Employee ID to Update:");
                    int updateId = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.println("Enter New Name:");
                    String newName = scanner.nextLine();
                    System.out.println("Enter New Department:");
                    String newDepartment = scanner.nextLine();
                    System.out.println("Enter New Salary:");
                    double newSalary = scanner.nextDouble();
                    database.updateEmployee(updateId, newName, newDepartment, newSalary);
                    break;

                case 3:
                    database.displayAllEmployees();
                    break;

                case 4:
                    Payroll.generatePayrollReport(database);
                    break;

                case 5:
                    System.out.println("Exiting...");
                    scanner.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice, please try again.");
                    break;
            }
        }
    }
}