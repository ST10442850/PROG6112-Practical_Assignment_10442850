import org.junit.Test;
import static org.junit.Assert.*;

public class EmployeeManagementTest {
    @Test
    public void testAddEmployee() {
        EmployeeDatabase database = new EmployeeDatabase();
        Employee employee = new Employee("John Doe", 101, "HR", 50000);
        database.addEmployee(employee);
        assertEquals(1, database.calculateTotalPayroll(), 50000);
    }

    private void assertEquals(double i, double v, int i1) {

    }

    @Test
    public void testUpdateEmployee() {
        EmployeeDatabase database = new EmployeeDatabase();
        Employee employee = new Employee("Jane Smith", 102, "Finance", 60000);
        database.addEmployee(employee);
        database.updateEmployee(102, "Jane Doe", "IT", 65000);
        double updatedSalary = 65000;
        assertEquals(updatedSalary, database.calculateTotalPayroll(), 65000);
    }
}
