import java.util.ArrayList;

public class EmployeeDatabase {
    private ArrayList<Employee> employees;

    public EmployeeDatabase() {
        employees = new ArrayList<>();
    }

    public void addEmployee(Employee employee) {
        employees.add(employee);
    }

    public void updateEmployee(int id, String name, String department, double salary) {
        for (Employee employee : employees) {
            if (employee.getId() == id) {
                employee.setName(name);
                employee.setDepartment(department);
                employee.setSalary(salary);
            }
        }
    }

    public void displayAllEmployees() {
        for (Employee employee : employees) {
            employee.displayEmployeeInfo();
        }
    }

    public double calculateTotalPayroll() {
        double totalPayroll = 0;
        for (Employee employee : employees) {
            totalPayroll += employee.getSalary();
        }
        return totalPayroll;
    }
}

